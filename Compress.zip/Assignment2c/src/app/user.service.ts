import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userData: any = null;

  register(user: any) {
    this.userData = user;  // Save user data in memory
  }

  login(email: string, password: string): boolean {
    return this.userData && this.userData.email === email && this.userData.password === password;
  }

  getUser() {
    return this.userData;
  }
}
