import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule,FormsModule] // Add this line
})

export class LoginComponent {
  email = '';
  password = '';
  loggedIn = false;
  loginFailed = false;

  constructor(private userService: UserService) {}

  loginUser() {
    if (this.userService.login(this.email, this.password)) {
      this.loggedIn = true;
      this.loginFailed = false;
    } else {
      this.loginFailed = true;
    }
  }
}
