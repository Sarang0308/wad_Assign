import { useState, useEffect } from "react";
import axios from "axios";

function App() {
    const [students, setStudents] = useState([]);
    const [formData, setFormData] = useState({ name: "", rollno: "", department: "", division: "", year: "" });

    // Fetch students on load
    useEffect(() => {
        axios.get("http://localhost:5000/students")
            .then(response => setStudents(response.data))
            .catch(error => console.error("Error fetching students:", error));
    }, []);

    // Handle form input change
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Handle form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:5000/students", formData)
            .then(() => {
                setStudents([...students, formData]);
                setFormData({ name: "", rollno: "", department: "", division: "", year: "" });
            })
            .catch(error => console.error("Error adding student:", error));
    };

    return (
        <div>
            <h1>Student List</h1>
            <ul>
                {students.map((student, index) => (
                    <li key={index}>
                        {student.name} - {student.rollno} - {student.department} - {student.division} - Year {student.year}
                    </li>
                ))}
            </ul>

            <h2>Add Student</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
                <input type="text" name="rollno" placeholder="Roll No" value={formData.rollno} onChange={handleChange} required />
                <input type="text" name="department" placeholder="Department" value={formData.department} onChange={handleChange} required />
                <input type="text" name="division" placeholder="Division" value={formData.division} onChange={handleChange} required />
                <input type="number" name="year" placeholder="Year" value={formData.year} onChange={handleChange} required />
                <button type="submit">Add Student</button>
            </form>
        </div>
    );
}

export default App;
